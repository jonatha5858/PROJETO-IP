package Teste;
import Contas.*;
import Excecoes.CPFJaCadastrado;
import RepositorioContas.Array_Usuario;
import RepositorioContas.Repositorio_Usuarios;

public class Projeto_OLX {
	
	public static Usuario [] usuarios = {
			new Comprador( "Erbert", "1001", Usuario.Estado.PE, 24.00),
			new Vendedor ( "Eric"  , "2302", Usuario.Estado.SP, 0.00),
			new Vendedor ( "Moises", "4503", Usuario.Estado.RJ, 200),
			new Comprador( "Caio"  , "1204", Usuario.Estado.SP, 4.00),
			new Comprador( "Jhony" , "1204", Usuario.Estado.RJ, 5.00)
	};
	private static Usuario user;

	public static void main(String[] args) {
		
		Repositorio_Usuarios repositorio;
		//repositorio = new Lista_Usuario();
		repositorio = new Array_Usuario();
		
		for(int i = 0; i < usuarios.length; i++) {
			try	{
				repositorio.Add (usuarios[i]);
				System.out.println(usuarios[i] + " |  Foi cadastrado com sucesso.");
			} catch (Excecoes.CPFJaCadastrado e) {
				System.out.println("Ja ha um usuario cadastrado com o CPF n� " + e.getCPF() + ".");
			}
		}
		
		
		System.out.println("\n" + repositorio.ToString());
		
		try
		{	 Usuario user = repositorio.Find("2304");	}
		catch (Excecoes.UsuarioNaoEncontrado e)
		{	System.out.println("Nenhum usuario com CPF n� " + (e.getCPF()) + " foi encontrado.");		}
		
		try
		{	repositorio.Remove("1204");}
		catch (Excecoes.UsuarioNaoEncontrado e)
		{	System.out.println("Nenhum usuario com CPF n� " + (e.getCPF()) + " foi encontrado.");		}
		
		System.out.println("\n" + repositorio.ToString());
	}
	
	
}
