package Contas;
import Teste.Produto;

public class Vendedor extends Usuario{
	
	public Vendedor(String nome, String CPF, Estado estado, double dinheiro) {
		setNome(nome);
		setCPF(CPF);
		setEstado(estado);
		setDinheiro(dinheiro);
	}
	
	public void Operacao(Produto produto) {
		System.out.println("Anunciar o produto: " + produto.getNome());
		//this.Usuario.CPF = 2;
	}

}
