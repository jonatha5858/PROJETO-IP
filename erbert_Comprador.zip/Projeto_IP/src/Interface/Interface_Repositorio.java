package Interface;

import Contas.Usuario;

public interface Interface_Repositorio {
	public void Add(Usuario usuario) throws Excecoes.CPFJaCadastrado;
	public void Remove(String CPF) throws Excecoes.UsuarioNaoEncontrado;
	public Usuario Find(String CPF) throws Excecoes.UsuarioNaoEncontrado;
	public boolean Exists(String CPF);
	public String ToString();
	
}
