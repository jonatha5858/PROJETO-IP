package RepositorioContas;

import Contas.Usuario;
import Contas.Vendedor;
import Interface.Interface_Repositorio;

public class Lista_Usuario extends Repositorio_Usuarios implements Interface_Repositorio{
	private Usuario primeiro, ultimo;
	
	Lista_Usuario() {
		primeiro = new Vendedor(null, null, null, 0);
		// VARIAVEL ARBITRARIA
		primeiro.setNext(null);
		ultimo = primeiro;
	}
	
	public void Add(Usuario usuario) throws Excecoes.CPFJaCadastrado {
		
		if(Exists(usuario.getCPF())) {
			throw new Excecoes.CPFJaCadastrado(usuario.getCPF());
		}
		
		ultimo.setNext(usuario);
		ultimo = usuario;
	}
	
	public void Remove(String CPF) throws Excecoes.UsuarioNaoEncontrado {
		Usuario user = primeiro;
		
		while(user.getNext() != null) {
			if(user.getNext().getCPF() == CPF) {
				user.setNext(user.getNext().getNext());
				return;
			}
			user = user.getNext();
		}
		
		throw new Excecoes.UsuarioNaoEncontrado(CPF); 
	}
	
	public Usuario Find(String CPF) throws Excecoes.UsuarioNaoEncontrado {
		Usuario user = primeiro;
		while(user.getNext() != null) {
			user = user.getNext();
			
			if(user.getCPF() == CPF) {
				return user;
			}
		}
		
		 throw new Excecoes.UsuarioNaoEncontrado(CPF); 
	}

	public boolean Exists(String CPF) {
		Usuario user = null;
		
		try
		{	user = Find(CPF);	}
		catch(Excecoes.UsuarioNaoEncontrado e)
		{	}
		
		if(user != null) {
			return true;
		} else {
			return false;
		}
	}
	
	public String ToString() {
		String retorno = "";
		Usuario user = primeiro.getNext();
		while(user != null) {
			//retorno += user.getNome() + " - " + user.getCPF() + "\n";
			retorno +=  user.toString() + "\n";
			
			
			user = user.getNext();
		}
		return retorno;
	}
	
}
