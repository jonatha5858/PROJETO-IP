package RepositorioContas;

import Contas.Usuario;
import Interface.Interface_Repositorio;

public class Array_Usuario extends Repositorio_Usuarios implements Interface_Repositorio {
	private Usuario [] usuarios;
	
	public Array_Usuario(){
		usuarios = new Usuario [20];
		for(int i = 0; i < usuarios.length; i++) {
			usuarios[i] = null;
		}
	}
	
	public void Add (Usuario usuario) throws Excecoes.CPFJaCadastrado {
		
		if(Exists(usuario.getCPF())) {
			throw new Excecoes.CPFJaCadastrado(usuario.getCPF());
		}
		
		for(int i = 0; i < usuarios.length; i++) {
			if(usuarios[i] == null) {
				usuarios[i] = usuario;
				return;
			}
		}
	}
	
	public void Remove (String CPF) throws Excecoes.UsuarioNaoEncontrado {
		for(int i = 0; i < usuarios.length; i++) {
			if(usuarios[i] != null) {
				if(usuarios[i].getCPF() == CPF) {
					usuarios[i] = null;
					return;
				}
			}
		}
		
		throw new Excecoes.UsuarioNaoEncontrado(CPF); 
	}
	
	public Usuario Find (String CPF) throws Excecoes.UsuarioNaoEncontrado {
		for(int i = 0; i < usuarios.length; i++) {
			Usuario usuario = usuarios[i];
			if(usuario != null) {
				if(usuario.getCPF() == CPF) {
					return usuario;
				}
			}
		}
		
		throw new Excecoes.UsuarioNaoEncontrado(CPF); 
	}
	
	public boolean Exists(String CPF) {
		Usuario user = null;
		
		try
		{	user = Find(CPF);	}
		catch(Excecoes.UsuarioNaoEncontrado e)
		{	}
		
		if(user != null) {
			return true;
		} else {
			return false;
		}
	}
	
	
	public String ToString() {
		String retorno = "";
		for(int i = 0; i < usuarios.length; i++) {
			Usuario usuario = usuarios[i];
			if(usuario != null) {
				retorno += usuario.toString() + "\n";
			}
		}
		
		return retorno;
	}
}
