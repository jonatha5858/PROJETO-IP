package RepositorioContas;

import Contas.Usuario;

public abstract class Repositorio_Usuarios {
	
	public abstract void Add(Usuario usuario) throws Excecoes.CPFJaCadastrado;

	public abstract void Remove(String CPF) throws Excecoes.UsuarioNaoEncontrado;
	
	public abstract Usuario Find(String CPF) throws Excecoes.UsuarioNaoEncontrado;
	
	public abstract boolean Exists(String CPF);
	
	public abstract String ToString();
	
}
