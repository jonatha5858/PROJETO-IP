package RepositorioVendedor;

import Contas.*;
import Contas.Usuario.*;
import Interface.*;

/*	Autor: 	Erbert
 *	Pacote: RepositorioVendedor
 */

public abstract class Repositorio_Vendedor implements Interface_Repositorio_Vendedor {
		
	public abstract void Adicionar(Vendedor vendedor);

	public abstract void Remover(String CPF) throws Excecoes.VendedorNaoEncontrado;
		
	public abstract Vendedor Procurar(String CPF) throws Excecoes.VendedorNaoEncontrado;
	
	public abstract boolean Existe(String CPF);
	
	public abstract String ToString();
	
}
