package RepositorioVendedor;

import Contas.Vendedor;
import Contas.Usuario.Estado;
import Excecoes.*;

/*	Autor: 	Erbert
 *	Pacote: RepositorioVendedor
 */

public class Cadastro_Vendedor {
	private Repositorio_Vendedor repositorio;

	public Cadastro_Vendedor(Repositorio_Vendedor repositorio) {
		this.repositorio = repositorio;
	}
	
	public void Cadastrar(String nome, String CPF, Estado estado, double dinheiro) throws CPFJaCadastrado {
		if(repositorio.Existe(CPF)) {
			throw new CPFJaCadastrado(CPF);
		} else {
			Vendedor vendedor = new Vendedor(nome, CPF, estado, 0);
			repositorio.Adicionar(vendedor);
		}
	}
	
	public void Remover(String CPF) throws VendedorNaoEncontrado {
		if(!repositorio.Existe(CPF)) {
			throw new VendedorNaoEncontrado(CPF);
		} else {
			//System.out.println()
			repositorio.Remover(CPF);
		}
	}
	
	public void Atualizar (Vendedor vendedor) throws VendedorNaoEncontrado {
		if(!repositorio.Existe(vendedor.getCPF())) {
			System.out.println("N�o encontrou o cpf ." + vendedor.getCPF() + ".");
			throw new VendedorNaoEncontrado(vendedor.getCPF());
		} else {
			Vendedor vendedor_ = repositorio.Procurar(vendedor.getCPF());
			vendedor_.setCPF(vendedor.getCPF());
			vendedor_.setNome(vendedor.getNome());
			vendedor_.setEstado(vendedor.getEstado());
			vendedor_.setDinheiro(vendedor.getDinheiro());
		}
	}
	
	public Vendedor Procurar (String CPF) throws VendedorNaoEncontrado {
		if(repositorio.Existe(CPF)) {
			throw new VendedorNaoEncontrado(CPF);
		} else {
			return repositorio.Procurar(CPF);
		}
	}
	
	public String ToString() {
		return repositorio.ToString();
	}
	

}
