package Teste;

import Contas.*;
import Excecoes.*;
import RepositorioVendedor.*;

/*	Autor: 	Erbert
 *	Pacote: Teste
 */

public class Projeto_OLX {
	
	public static Vendedor [] usuarios = {
			new Vendedor ( "Erbert", "1001", Usuario.Estado.PE, 24.00),
			new Vendedor ( "Eric"  , "2302", Usuario.Estado.SP, 0.00),
			new Vendedor ( "Moises", "4503", Usuario.Estado.RJ, 200),
			new Vendedor ( "Caio"  , "2302", Usuario.Estado.SP, 4.00),
			new Vendedor ( "Jhony" , "1204", Usuario.Estado.RJ, 5.00)
	};

	public static void main(String[] args) {
		Cadastro_Vendedor repositorio;
		
		
		//			SELECAO DO TIPO DE REPOSITORIO
		repositorio = new Cadastro_Vendedor(new Array_Vendedor());
		//repositorio = new Cadastro_Vendedor(new Lista_Vendedor());
		
		
		//			PREENCIMENTO DO REPOSIT�RIO
		for(int i = 0; i < usuarios.length; i++) {
			try	{
				repositorio.Cadastrar (usuarios[i].getNome(), usuarios[i].getCPF(), usuarios[i].getEstado(), usuarios[i].getDinheiro());
				System.out.println(usuarios[i] + " |  Foi cadastrado com sucesso.");
			} catch (CPFJaCadastrado e) {
				System.out.println("Ja ha um usuario cadastrado com o CPF n� " + e.getCPF() + ".");
			}
		}
		
		
		
		//			TESTE DE BUSCA DE UM VENDEDOR POR SEU CPF
		/*try
		{	 Usuario user = repositorio.Procurar("2304");	}
		catch (Excecoes.VendedorNaoEncontrado e)
		{	System.out.println("Nenhum usuario com CPF n� " + (e.getCPF()) + " foi encontrado.");		}
		*/
		
		
		
		//			TESTE DE REMOCAO DE UM VENDEDOR POR SEU CPF
		/*try	{
			repositorio.Remover("1001");
			System.out.println("O CPF n� " + ("1001") + " foi removido.");
		} catch (Excecoes.VendedorNaoEncontrado e) {
			System.out.println("Nenhum usuario com CPF n� " + (e.getCPF()) + " foi encontrado.");
		}*/
		
		
		
		//			TESTE DE ATUALIZACAO DOS DADOS DE UM DETERMINADO VENDEDOR
		/*try {
			repositorio.Atualizar(new Vendedor("Erbert 2.0", "1001", null, 0));
		} catch (Excecoes.VendedorNaoEncontrado e) {
			System.out.println("Nenhum usuario com CPF n� " + (e.getCPF()) + " foi encontrado.");
		}*/
		
		System.out.println("\n" + repositorio.ToString());
	}
	
	
}
