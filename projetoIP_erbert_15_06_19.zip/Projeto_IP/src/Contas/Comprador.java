package Contas;

import Teste.Produto;

/*	Autor: 	Erbert
 *	Pacote: Contas
 */

public class Comprador extends Usuario{
	
	public Comprador(String nome, String CPF, Estado estado, double dinheiro) {
		setNome(nome);
		setCPF(CPF);
		setEstado(estado);
		setDinheiro(dinheiro);
	}
	
	public void Transacao(Produto produto) {
		
		if(getDinheiro() <= produto.getPreco()) {
			System.out.println("Faltam " + (produto.getPreco() - getDinheiro()) + " para que voc� possa comprar este " + produto.getNome());
			return;
		}
		
		System.out.println(this.getNome() + " comprou " + produto.getNome() + " de " + produto.getVendedor());
		
	}
	
	public void Transacao (String nome_produto, double preco, int quantidade) {
		
		if(getDinheiro() <= preco) {
			System.out.println("Faltam " + (preco- getDinheiro()) + " para que voc� possa comprar este " + nome_produto);
			return;
		}
		
		System.out.println(this.getNome() + " comprou " + preco + " de " + "");
		
	}
	
}
