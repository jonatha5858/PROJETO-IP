package Contas;

import Teste.Produto;

/*	Autor: 	Erbert
 *	Pacote: Contas
 */

public class Vendedor extends Usuario{
	
	private Vendedor next;
	
	public Vendedor(String nome, String CPF, Estado estado, double dinheiro) {
		setNome(nome);
		setCPF(CPF);
		setEstado(estado);
		setDinheiro(dinheiro);
	}
	
	public void Transacao(Produto produto) {
		System.out.println("Anunciar o produto: " + produto.getNome());
	}
	
	public void Transacao(String nome_produto, double preco, int quantidade) {
		System.out.println("Anunciar o produto: " + nome_produto);
		Anunciar(nome_produto, preco, quantidade);
	}
	
	public void Anunciar (String nome_produto, double preco, int quantidade) {
		Produto produto = new Produto(nome_produto, getCPF(), preco, quantidade);
	}
	
	public Vendedor getNext() {
		return next;
	}
	
	public void setNext(Vendedor next) {
		this.next = next;
	}

}
