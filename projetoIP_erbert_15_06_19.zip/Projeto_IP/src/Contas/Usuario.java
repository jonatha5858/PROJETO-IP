package Contas;

import Teste.Produto;

/*	Autor: 	Erbert
 *	Pacote: Contas
 */

public abstract class Usuario {
	
	private String nome;
	private double dinheiro;
	private String CPF;
	
	private Estado estado;
	public enum Estado{
		PE,
		SP,
		RJ
		}
	
	public enum TipoConta{
		VENDEDOR,
		COMPRADOR
	}
	
	public abstract void Transacao (Produto produto);
	
	public abstract void Transacao (String nome_produto, double preco, int quantidade);
	
	
	public String toString () {
		return "Nome: " + nome + getSpace(10 - nome.length()) +
				"-  CPF: " + CPF + getSpace(7 - CPF.length()) +
				"  -  Estado: " + (estado != null?estado.name():"_") +
				"  -  Dinheiro: " + dinheiro + getSpace(9 - Double.toString(dinheiro).toString().length());
		
	}
	
	private String getSpace(int param) {
		String retorno = "";
		for(int i = 1; i < param; i++) {
			retorno += " ";
		}
		return retorno;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getNome() {
		return nome;
	}
	
	
	public void setCPF(String CPF) {
		this.CPF = CPF;
	}
	public String getCPF() {
		return CPF;
	}
	
	
	public void setDinheiro(double dinheiro) {
		this.dinheiro = dinheiro;
	}
	public double getDinheiro() {
		return dinheiro;
	}
	
	
	public void setEstado(Estado estado) {
		this.estado = estado;
	}
	public Estado getEstado() {
		return estado;
	}
	
}
