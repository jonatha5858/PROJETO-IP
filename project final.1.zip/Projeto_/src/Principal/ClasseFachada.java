package Principal;

import Excecoes.*;
import Comprador.*;
import Vendedor.*;
import Usuario.*;
import Produto.*;
import Transacao.*;

@SuppressWarnings("unused")
public class ClasseFachada {
	
	
	//Rep. Comprador
	//CadastroCompradores compradores;
	//Rep. Vendedor
	Cadastro_Vendedor vendedores;
	//Rep. Produto
	Cadastro_Produtos produtos;
	//Rep. Transacao
	Repositorio_lista_Transacao transacoes;
	
    public enum Repositorio {
    	ARRAY,
    	LISTA
    }
    
	public ClasseFachada(Repositorio tipoRepositorio) {
		if(tipoRepositorio == Repositorio.ARRAY) {
			vendedores	= new Cadastro_Vendedor( new Array_Vendedor());
			produtos	= new Cadastro_Produtos( new RepositorioProdutosArray());
		} else {
			vendedores	= new Cadastro_Vendedor( new Lista_Vendedor());
			produtos	= new Cadastro_Produtos( new RepositorioProdutosLista());
		}
	}
	
	public void Adicionar_Vendedor(Vendedor vendedor) throws CPFJaCadastrado_Exception {
		try	{
			vendedores.Cadastrar (vendedor);
		} catch (CPFJaCadastrado_Exception e) {
			throw e;
		}
	}
	
	public Vendedor Procurar_Vendedor(String CPF) throws VendedorNaoEncontrado_Exception {
		try {
			return vendedores.Procurar(CPF);
		} catch (Exception e) {
			throw new VendedorNaoEncontrado_Exception(CPF);
		}
	}
	
	public String getVendedores() {
		return vendedores.ToString();
	}

	public Cadastro_Produtos getReferenciaLoja() {
		return produtos;
	}
}
