package Principal;

import Excecoes.*;
import Comprador.*;
import Vendedor.*;
import Usuario.*;
import Produto.*;
import Transacao.*;
import Principal.ClasseFachada.Repositorio;

@SuppressWarnings("unused")
public class Main {
	
	static Vendedor [] vendedores = {
			new Vendedor ( "Marcos", "1001", "PE", 24.00),
			new Vendedor ( "Joooao", "4503", "RJ", 200),
			new Vendedor ( "Felipe"  , "1001", "MA", 4.00),
	};


    public static void main(String[] args) {
    	ClasseFachada classeFachada;
    	classeFachada = new ClasseFachada(Repositorio.ARRAY);
    	//classeFachada = new ClasseFachada(Repositorio.LISTA);
    	
    	
    	//					ROTEIRO
    	//	Criar um vendedor e anunciar uns produtos
    	//	Criar um comprador e comprar uns produtos
    	//	Exibir as todas as transacoes realizadas
    	
    	
    	
    	// ADICIONA E BUSCA VENDEDORES EM SEU REPOSITORIO
    	System.out.println();
	    	for(int i = 0; i < vendedores.length; i++) {
	        	try {
	        		classeFachada.Adicionar_Vendedor(vendedores[i]);
	        		System.out.println("Sucesso: .");
	        	} catch (CPFJaCadastrado_Exception e) {
	        		System.out.println("Erro: O CPF n�" + e.getCPF() + " ja esta em uso.");
	        	}
	    	}
	    	System.out.println(classeFachada.getVendedores());
	    	
	    	Vendedor Joao = new Vendedor(null, null, null, 0);
	    	try {
	    		Joao = classeFachada.Procurar_Vendedor("5030");
	    		System.out.println(Joao);
	    	} catch (VendedorNaoEncontrado_Exception e) {
	    		System.out.println("Erro: Nao ha nenhum usuario com o CPF n�" + e.getCPF() + ".");
	    	}
	    	
	    	try {
	    		Joao = classeFachada.Procurar_Vendedor("4503");
	    		Joao.setNome("Joao");
	    		System.out.println(Joao);
	    	} catch (VendedorNaoEncontrado_Exception e) {
	    		System.out.println("Erro: Nao ha nenhum usuario com o CPF n�" + e.getCPF() + ".");
	    	}
    	
	    // ANUNCIO DE UM PRODUTO
	    System.out.println();
	    	Produtos celular = new Produtos();
	    	celular.setNome("Celular");
	    	celular.setPreco(110);
	    	celular.setCodigo("1234");
	    	celular.setVendedor(Joao.getCPF());
	    	
	    	try {
	    		Joao.Transacao(celular, classeFachada.getReferenciaLoja());
	    		System.out.println("Sucesso: O produto foi anunciado.");
	    	} catch(PJCException e) {
	    		System.out.println("Erro: O codigo inserido ja esta em uso.");
	    	}
	    	
	    	try {
	    		Joao.Transacao(celular, classeFachada.getReferenciaLoja());
	    		System.out.println("Sucesso: O produto foi anunciado.");
	    	} catch(PJCException e) {
	    		System.out.println("Erro: O codigo inserido ja esta em uso.");
	    	}
    	
    	
    }
    
    
    
}
