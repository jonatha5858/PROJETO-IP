/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Produto;

import Excecoes.*;
import Vendedor.*;
/**
 *
 * @author mas8
 */
public class Produtos {
    private String nome;
    private String codigo;
    private float preco;
    private String cpfVendedor;
    
    public Produtos(){
        this.nome = null;
        this.codigo = null;
        this.preco = 0;
        this.cpfVendedor = "----";
    }
    
    public Produtos(String nome, String codigo, float preco, String cpfVendedor){
        this.nome = nome;
        this.codigo = codigo;
        this.preco = preco;
        this.cpfVendedor = cpfVendedor;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    public void setCodigo(String codigo){
        this.codigo = codigo;
    }
    public void setPreco(float preco){
        this.preco = preco;
    }
    public void setVendedor(String cpfVendedor){
        this.cpfVendedor = cpfVendedor;
    }
    
    public String getNome(){
        return this.nome;
    }
    public String getCodigo(){
        return this.codigo;
    }
    public float getPreco(){
        return this.preco;
    }
    public String getCpfVendedor(){
        return this.cpfVendedor;
    }
    public Vendedor getVendedor(){
        //return RepositorioVendedores.procurar(this.cpfdovendedor);
    	System.out.println("Produto>Produtos>getVendedor: Pesquisar o vendedor no reposit�rio.");
    	return new Vendedor(null, null, null, 0);
    	
    }
}
