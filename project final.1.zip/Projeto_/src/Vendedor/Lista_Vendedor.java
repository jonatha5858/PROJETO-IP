package Vendedor;

/*	Autor: 	Erbert
 *	Pacote: RepositorioVendedor
 */

public class Lista_Vendedor extends Repositorio_Vendedor {
	private Vendedor primeiro, ultimo;
	
	public Lista_Vendedor() {
		primeiro = new Vendedor(null, null, null, 0);
		// VARIAVEL ARBITRARIA
		primeiro.setNext(null);
		ultimo = primeiro;
	}
	
	public void Adicionar(Vendedor vendedor) {
		ultimo.setNext(vendedor);
		ultimo = vendedor;
	}
	
	public void Remover(String CPF) {
		Vendedor user = primeiro;
		
		while(user.getNext() != null) {
			if(user.getNext().getCPF() == CPF) {
				user.setNext(user.getNext().getNext());
				return;
			}
			user = user.getNext();
		}
		
	}

	public Vendedor Procurar(String CPF) {
		Vendedor vendedor = primeiro;
		while(vendedor.getNext() != null) {
			vendedor = vendedor.getNext();
			
			if(vendedor.getCPF() == CPF) {
				break;
			}
		}
		
		return vendedor;
	}

	public boolean Existe(String CPF) {
		Vendedor user = primeiro;
		
		while(user.getNext() != null) {
			if(user.getNext().getCPF().equals(CPF))
			{	return true;			}
			user = user.getNext();
		}
		
		return false;
	}

	public String ToString() {
		String retorno = "";
		Vendedor user = primeiro.getNext();
		while(user != null) {
			retorno +=  user.toString() + "\n";
			user = user.getNext();
		}
		return retorno;
	}

	
}
