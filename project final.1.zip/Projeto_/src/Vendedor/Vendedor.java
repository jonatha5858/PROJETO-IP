package Vendedor;

import Usuario.*;
import Excecoes.PJCException;
import Produto.*;

/*	Autor: 	Erbert
 *	Pacote: Contas
 */

public class Vendedor extends Usuario{
	
	private Vendedor next;
	
	public Vendedor(String nome, String CPF, String estado, double dinheiro) {
		setNome(nome);
		setCPF(CPF);
		setEstado(estado);
		setDinheiro(dinheiro);
	}
	
	public void Transacao(Produtos produto, Cadastro_Produtos referenciaLoja) throws PJCException {
		try {
			referenciaLoja.cadastrar(produto);
		} catch(PJCException e) {
			throw e;
		}
	}
	
	public Vendedor getNext() {
		return next;
	}
	
	public void setNext(Vendedor next) {
		this.next = next;
	}

}
