package Vendedor;

import Excecoes.*;
/*
import Contas.*;
*/
/*	Autor: 	Erbert
 *	Pacote: Interface
 */

public interface Interface_Repositorio_Vendedor {
	public void Adicionar(Vendedor vendedor) throws CPFJaCadastrado_Exception;
	public void Remover(String CPF) throws VendedorNaoEncontrado_Exception;
	public Vendedor Procurar(String CPF) throws VendedorNaoEncontrado_Exception;
	public boolean Existe(String CPF);
	public String ToString();
	
}
