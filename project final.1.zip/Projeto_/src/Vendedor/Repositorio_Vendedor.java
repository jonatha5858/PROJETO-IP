package Vendedor;

/*	Autor: 	Erbert
 *	Pacote: RepositorioVendedor
 */

public abstract class Repositorio_Vendedor implements Interface_Repositorio_Vendedor {
		
	public abstract void Adicionar(Vendedor vendedor);

	public abstract void Remover(String CPF);
		
	public abstract Vendedor Procurar(String CPF);
	
	public abstract boolean Existe(String CPF);
	
	public abstract String ToString();
	
}
