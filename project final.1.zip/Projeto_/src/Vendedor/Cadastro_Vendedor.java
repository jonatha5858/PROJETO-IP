package Vendedor;

import Excecoes.*;
/*
import Contas.Vendedor;
import Contas.Usuario.Estado;
import Excecoes.*;
*/

/*	Autor: 	Erbert
 *	Pacote: RepositorioVendedor
 */

public class Cadastro_Vendedor {
	private Repositorio_Vendedor repositorio;

	public Cadastro_Vendedor(Repositorio_Vendedor repositorio) {
		this.repositorio = repositorio;
	}
	
	public void Cadastrar(String nome, String CPF, String estado, double dinheiro) throws CPFJaCadastrado_Exception {
		if(repositorio.Existe(CPF)) {
			throw new CPFJaCadastrado_Exception(CPF);
		} else {
			Vendedor vendedor = new Vendedor(nome, CPF, estado, dinheiro);
			repositorio.Adicionar(vendedor);
		}
	}
	
	public void Cadastrar(Vendedor vendedor) throws CPFJaCadastrado_Exception {
		if(repositorio.Existe(vendedor.getCPF())) {
			throw new CPFJaCadastrado_Exception(vendedor.getCPF());
		} else {
			repositorio.Adicionar(vendedor);
		}
	}
	
	public void Remover(String CPF) throws VendedorNaoEncontrado_Exception {
		if(!repositorio.Existe(CPF)) {
			throw new VendedorNaoEncontrado_Exception(CPF);
		} else {
			//System.out.println()
			repositorio.Remover(CPF);
		}
	}
	
	public void Atualizar (Vendedor vendedor) throws VendedorNaoEncontrado_Exception {
		if(!repositorio.Existe(vendedor.getCPF())) {
			System.out.println("N�o encontrou o cpf ." + vendedor.getCPF() + ".");
			throw new VendedorNaoEncontrado_Exception(vendedor.getCPF());
		} else {
			Vendedor vendedor_ = repositorio.Procurar(vendedor.getCPF());
			vendedor_.setCPF(vendedor.getCPF());
			vendedor_.setNome(vendedor.getNome());
			vendedor_.setEstado(vendedor.getEstado());
			vendedor_.setDinheiro(vendedor.getDinheiro());
		}
	}
	
	public Vendedor Procurar (String CPF) throws VendedorNaoEncontrado_Exception {
		if(!repositorio.Existe(CPF)) {
			throw new VendedorNaoEncontrado_Exception(CPF);
		} else {
			return repositorio.Procurar(CPF);
		}
	}
	
	public String ToString() {
		return repositorio.ToString();
	}
	

}
