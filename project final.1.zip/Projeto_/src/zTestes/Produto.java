package zTestes;

/*	Autor: 	Erbert
 *	Pacote: Teste
 */

public class Produto {
	
	private String nome,
				   vendedor;
	
	private int quantidade;
	private double preco;
	
	public Produto(String nome, String vendedor, double preco, int quantidade) {
		this.nome = nome;
		this.vendedor = vendedor;
		this.preco = preco;
		this.quantidade = quantidade;
	}
	
	public Produto(String nome, String vendedor, double preco) {
		this.nome = nome;
		this.vendedor = vendedor;
		this.preco = preco;
		this.quantidade = 1;
	}
	
	public void RepositorioLoja() {
		
	}
	
	public String getNome() {
		return nome;
	}
	public String getVendedor() {
		return vendedor;
	}
	public double getPreco() {
		return preco;
	}
	public int getQuantidade() {
		return quantidade;
	}
	
}
