package Usuario;

import Produto.*;
import Excecoes.*;

/*	Autor: 	Erbert
 *	Pacote: Contas
 */

public abstract class Usuario {
	
	private String nome;
	private double dinheiro;
	private String CPF;
	
	private String estado;

	
	public abstract void Transacao (Produtos produto, Cadastro_Produtos referenciaLoja) throws PJCException, PNEException;
	
	public String toString () {
		return "Nome: " + nome + getSpace(10 - nome.length()) +
				"-  CPF: " + CPF + getSpace(7 - CPF.length()) +
				"  -  Estado: " + estado + getSpace(5 - estado.length()) +
				"  -  Dinheiro: " + dinheiro + getSpace(9 - Double.toString(dinheiro).toString().length());
		
	}
	
	private String getSpace(int param) {
		String retorno = "";
		for(int i = 1; i < param; i++) {
			retorno += " ";
		}
		return retorno;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getNome() {
		return nome;
	}
	
	
	public void setCPF(String CPF) {
		this.CPF = CPF;
	}
	public String getCPF() {
		return CPF;
	}
	
	
	public void setDinheiro(double dinheiro) {
		this.dinheiro = dinheiro;
	}
	public double getDinheiro() {
		return dinheiro;
	}
	
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getEstado() {
		return estado;
	}
	
}
